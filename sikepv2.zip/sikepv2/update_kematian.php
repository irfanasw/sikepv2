<?php

include "koneksi.php";
$no_reg_pend = $_GET['no_reg_pend'];
$no_surat_kematian=$_POST['no_surat_kematian'];
$no_reg_pend=$_POST['no_reg_pend'];
$nik=$_POST['nik'];
$nama=$_POST['nama'];
$tempat=$_POST['tempat'];
$tanggal_lahir =  $_POST['tanggal_lahir'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$agama=$_POST['agama'];
$status_nikah=$_POST['status_nikah'];
$pekerjaan=$_POST['pekerjaan'];
$no_kk=$_POST['no_kk'];
$no_rt=$_POST['no_rt'];
$no_rw=$_POST['no_rw'];
$tanggal_input = $_POST['tanggal_input'];


$tanggal_meninggal =  $_POST['thn_mngl']."-".$_POST['bln_mngl']."-".$_POST['tgl_mngl'];
$tempat_meninggal=$_POST['tempat_meninggal'];
$desa=$_POST['desa'];
$kota=$_POST['kota'];
$sebab=$_POST['sebab'];
$oleh=$_POST['oleh'];
$hari_meninggal=$_POST['hari_meninggal'];

$hitunghari['awal'] = $tanggal_lahir;
$hitunghari['akhir'] = $tanggal_meninggal;

$tahun = $hitunghari['akhir'] - $hitunghari['awal'];
if(empty($nama))
{
die("Isikan Nama!");
}
else
{

$myquery1="update tb_kematian set tanggal_meninggal='$tanggal_meninggal',hari_meninggal='$hari_meninggal',umur='$tahun',tempat_meninggal='$tempat_meninggal',".
"desa='$desa',kota='$kota',sebab='$sebab',oleh='$oleh',tanggal_input='$tanggal_input' WHERE no_surat_kematian='$no_surat_kematian' LIMIT 1";


mysql_query($myquery1) or die(mysql_error());


echo '<script type="text/javascript">alert("Data telah diupdate, Silahkan tunggu...");
location.href="kematian.php";</script>';
}


?>

