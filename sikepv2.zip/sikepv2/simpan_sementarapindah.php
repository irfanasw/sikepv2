<?php

include "koneksi.php";
$nik=$_POST['nik']; 
$q1="insert into tb_sementarapindah( no_reg_pend, nama,nik, jenis_kelamin,tempat, tanggal_lahir,agama,status_nikah,status_hub,pendidikan,pekerjaan, no_kk,no_rt,no_rw) select no_reg_pend, nama,nik, jenis_kelamin,tempat, tanggal_lahir,agama, status_nikah,status_hub, pendidikan,pekerjaan,no_kk,no_rt,no_rw from tb_penduduk where nik='$nik' limit 1";
mysql_query($q1)or die(mysql_error());
header ("location:input_pindah.php");                                          

?>