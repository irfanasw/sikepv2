DROP TABLE tb_admin;

CREATE TABLE `tb_admin` (
  `ID` int(2) NOT NULL,
  `NAMA` varchar(20) NOT NULL,
  `USERNAME` varchar(20) NOT NULL,
  `PASSWORD` varchar(10) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_admin VALUES("1","ADMIN","ADMIN","ADMIN");



DROP TABLE tb_agama;

CREATE TABLE `tb_agama` (
  `id` int(2) NOT NULL,
  `agama` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_agama VALUES("1","Islam");
INSERT INTO tb_agama VALUES("2","Kristen");
INSERT INTO tb_agama VALUES("3","Katholik");
INSERT INTO tb_agama VALUES("4","Hindu");
INSERT INTO tb_agama VALUES("5","Budha");
INSERT INTO tb_agama VALUES("6","Konghucu");
INSERT INTO tb_agama VALUES("7","Lainnya");



DROP TABLE tb_detail_kematian;

CREATE TABLE `tb_detail_kematian` (
  `no_surat_kematian` varchar(20) NOT NULL,
  `no_reg_pend` varchar(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_detail_kematian VALUES("474.3/001/2014","Reg00035","3328021109450090","DUMISAH","Perempuan","Tegal","1945-09-11"," Islam "," Cerai Mati "," Petani/Pekebun ","3328020708080008","6","1");



DROP TABLE tb_detail_kk;

CREATE TABLE `tb_detail_kk` (
  `no_reg_kk` varchar(10) NOT NULL,
  `no_reg_pend` varchar(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `no_akta` varchar(20) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `no_akta_nikah` varchar(20) NOT NULL,
  `tanggal_nikah` varchar(12) NOT NULL,
  `no_akta_cerai` varchar(20) NOT NULL,
  `tanggal_cerai` varchar(12) NOT NULL,
  `status_hub` varchar(20) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `nama_ayah` varchar(30) NOT NULL,
  `nama_ibu` varchar(30) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_detail_kk VALUES("KK00001","Reg00012","-","MUZAYIN","Laki-laki","Tegal","1964-08-12","-"," Islam "," Kawin ","437/16/XI/1995","01-11-1995","-","-"," Kepala Keluarga "," Tamat SD/Sederajat "," Sopir ","AKTIF","MAFRUHAH","3","1");
INSERT INTO tb_detail_kk VALUES("KK00001","Reg00013","-","NURNA RUKINI","Perempuan","Magelang","1973-07-18","-"," Islam "," Kawin ","437/16/XI/1995","01-11-1995","-","-"," Istri "," SLTP/Sederajat "," Mengurus Rumah Tangga ","MBUH","SURANI","3","1");
INSERT INTO tb_detail_kk VALUES("KK00001","Reg00014","-","FADHLIYAH NURZA","Perempuan","Magelang","1996-08-19","4260/1996"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTP/Sederajat "," Pelajar/Mahasiswa ","MUZAYIN","NURNA RUKINI","3","1");
INSERT INTO tb_detail_kk VALUES("KK00001","Reg00015","-","FAUZIATUNNISA NURZA","Perempuan","Magelang","1998-03-19","3727/TP/2007"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTP/Sederajat "," Pelajar/Mahasiswa ","MUZAYIN","NURNA RUKINI","3","1");
INSERT INTO tb_detail_kk VALUES("KK00001","Reg00016","-","NAZIHA NABIL NURZA","Perempuan","Magelang","2007-01-19","10355/TP/2007"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Belum Tamat SD/Sederajat "," Pelajar/Mahasiswa ","MUZAYIN","NURNA RUKINI","3","1");
INSERT INTO tb_detail_kk VALUES("KK00002","Reg00017","-","SUKAMTO","Laki-laki","Brebes","1975-08-14","-"," Islam "," Kawin ","132/06/VI/1994","06-06-1994","-","-"," Kepala Keluarga "," Tamat SD/Sederajat "," Buruh Harian Lepas ","KAPUT SUTIKNO","SEKHA","5","3");
INSERT INTO tb_detail_kk VALUES("KK00002","Reg00018","-","TOBIAH","Perempuan","Tegal","1975-03-12","-"," Islam "," Kawin ","132/06/VI/1994","06-06-1994","-","-"," Istri "," Tamat SD/Sederajat "," Mengurus Rumah Tangga ","DAHLAN","DEMAH","5","3");
INSERT INTO tb_detail_kk VALUES("KK00002","Reg00019","-","WIDIASTUTI","Perempuan","Tegal","1996-04-20","997/TPJB/2002"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTP/Sederajat "," Pelajar/Mahasiswa ","SUKAMTO","TOBIAH","5","3");



DROP TABLE tb_detail_ktp;

CREATE TABLE `tb_detail_ktp` (
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_hub` varchar(20) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_detail_ktp VALUES("3328020201650001","ABDILLAH","Laki-laki","Tegal","1965-01-02","Islam","Kepala Keluarga","Kawin","SLTA/Sederajat","Wiraswasta","3328022703140004","6","1");



DROP TABLE tb_detail_pend_masuk;

CREATE TABLE `tb_detail_pend_masuk` (
  `no_surat_masuk` varchar(30) NOT NULL,
  `no_reg_pend` varchar(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `umur` int(2) NOT NULL,
  `no_akta` varchar(20) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `no_akta_nikah` varchar(20) NOT NULL,
  `tanggal_nikah` varchar(12) NOT NULL,
  `no_akta_cerai` varchar(20) NOT NULL,
  `tanggal_cerai` varchar(12) NOT NULL,
  `status_hub` varchar(20) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `nama_ayah` varchar(30) NOT NULL,
  `nama_ibu` varchar(30) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `no_surat_kelahiran` varchar(20) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_reg_pend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_detail_pend_masuk VALUES("SKPWNI/3304/18082014/0025","Reg00028","3304045612850002","ANIP","Perempuan","Banjarnegara","1985-12-15","0","-"," Islam "," Kawin ","780/36/XII/2006","19-12-2006","-","-"," Anak "," SLTP/Sederajat "," Mengurus Rumah Tangga ","SARTONO","RUSMIATI","3304040703054764","-","1","4","2014-08-18");
INSERT INTO tb_detail_pend_masuk VALUES("SKPWNI/3304/18082014/0025","Reg00029","3304046004080003","AFRILIANI","Perempuan","Banjarnegara","2008-04-20","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Cucu "," Belum Tamat SD/Sederajat "," Pelajar/Mahasiswa ","KHUSNUL","ANIP","3304040703054764","-","1","4","2014-08-18");



DROP TABLE tb_detail_pend_pindah;

CREATE TABLE `tb_detail_pend_pindah` (
  `no_surat_pindah` varchar(20) NOT NULL,
  `no_reg_pend` varchar(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `status_hub` varchar(20) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_detail_pend_pindah VALUES("470/001/2014","Reg00035","3328021111900002","A","Laki-laki","Tegal","1990-11-11"," Islam "," Cerai Hidup "," Kepala Keluarga "," Buruh Harian Lepas "," SLTA/Sederajat ","3328021212120004","3","3");



DROP TABLE tb_jenis_kelamin;

CREATE TABLE `tb_jenis_kelamin` (
  `jenis_kelamin` varchar(10) NOT NULL,
  PRIMARY KEY  (`jenis_kelamin`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_jenis_kelamin VALUES("Laki-laki");
INSERT INTO tb_jenis_kelamin VALUES("Perempuan");



DROP TABLE tb_kelahiran;

CREATE TABLE `tb_kelahiran` (
  `no_surat_kelahiran` varchar(20) NOT NULL,
  `no_reg_pend` varchar(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `hari` varchar(15) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `nama_ibu` varchar(25) NOT NULL,
  `nama_ayah` varchar(25) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_surat_kelahiran`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_kelahiran VALUES("474.1/001/2014","Reg00033","MASKAN DIYAUL MISKI","Laki-laki","Kamis Pon","Tegal","2014-08-07","SUSIAWATI","MUHAMMAD LUBSI","3328021809130018","6","1","2014-09-03");
INSERT INTO tb_kelahiran VALUES("474.1/002/2014","Reg00034","SAYYIDAH LUTFANIL AULADA","Perempuan","Kamis Pon","Tegal","2014-08-07","SUSIAWATI","MUHAMMAD LUBSI","3328021809130018","6","1","2014-09-03");



DROP TABLE tb_kematian;

CREATE TABLE `tb_kematian` (
  `no_surat_kematian` varchar(20) NOT NULL,
  `tanggal_meninggal` date NOT NULL,
  `hari_meninggal` varchar(6) NOT NULL,
  `umur` int(2) NOT NULL,
  `tempat_meninggal` varchar(20) NOT NULL,
  `sebab` varchar(50) NOT NULL,
  `desa` varchar(15) NOT NULL,
  `kota` varchar(15) NOT NULL,
  `oleh` varchar(20) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_surat_kematian`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_kematian VALUES("474.3/001/2014","2014-11-21","Senin","69","Bukan Rumah Sakit","SAKIT","CEMPAKA","TEGAL","Lainnya","2014-11-21");



DROP TABLE tb_kk;

CREATE TABLE `tb_kk` (
  `no_reg_kk` varchar(10) NOT NULL,
  `nama_kk` varchar(25) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `jml_anggota` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_reg_kk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_kk VALUES("KK00001","MUZAYIN","3","1","5","2014-01-06");
INSERT INTO tb_kk VALUES("KK00002","SUKAMTO","5","3","3","2014-01-08");



DROP TABLE tb_ktp;

CREATE TABLE `tb_ktp` (
  `nik` varchar(16) NOT NULL,
  `tanggal_input` date NOT NULL,
  `tanggal_berlaku` date NOT NULL,
  PRIMARY KEY  (`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_ktp VALUES("3328020201650001","2014-12-08","2019-01-02");



DROP TABLE tb_pekerjaan;

CREATE TABLE `tb_pekerjaan` (
  `kd_kerja` int(2) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  PRIMARY KEY  (`kd_kerja`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_pekerjaan VALUES("1","Belum/Tidak Bekerja");
INSERT INTO tb_pekerjaan VALUES("2","Mengurus Rumah Tangga");
INSERT INTO tb_pekerjaan VALUES("3","Pelajar/Mahasiswa");
INSERT INTO tb_pekerjaan VALUES("4","Pensiunan");
INSERT INTO tb_pekerjaan VALUES("5","Pegawai Negeri Sipil (PNS)");
INSERT INTO tb_pekerjaan VALUES("6","Tentara Nasional Indonesia (TNI)");
INSERT INTO tb_pekerjaan VALUES("7","Kepolisian RI (POLRI)");
INSERT INTO tb_pekerjaan VALUES("8","Perdagangan");
INSERT INTO tb_pekerjaan VALUES("9","Petani/Pekebun");
INSERT INTO tb_pekerjaan VALUES("10","Peternak");
INSERT INTO tb_pekerjaan VALUES("11","Nelayan/Perikanan");
INSERT INTO tb_pekerjaan VALUES("12","Industri");
INSERT INTO tb_pekerjaan VALUES("13","Konstruksi");
INSERT INTO tb_pekerjaan VALUES("14","Transportasi");
INSERT INTO tb_pekerjaan VALUES("15","Karyawan Swasta");
INSERT INTO tb_pekerjaan VALUES("16","Karyawan BUMN");
INSERT INTO tb_pekerjaan VALUES("17","Karyawan BUMD");
INSERT INTO tb_pekerjaan VALUES("18","Karyawan Honorer");
INSERT INTO tb_pekerjaan VALUES("19","Buruh Harian Lepas");
INSERT INTO tb_pekerjaan VALUES("20","Buruh Tani/Perkebunan");
INSERT INTO tb_pekerjaan VALUES("21","Buruh Nelayan/Perikanan");
INSERT INTO tb_pekerjaan VALUES("22","Buruh Peternakan");
INSERT INTO tb_pekerjaan VALUES("23","Pembantu Rumah Tangga");
INSERT INTO tb_pekerjaan VALUES("24","Tukang Cukur");
INSERT INTO tb_pekerjaan VALUES("25","Tukang Listrik");
INSERT INTO tb_pekerjaan VALUES("26","Tukang Batu");
INSERT INTO tb_pekerjaan VALUES("27","Tukang Kayu");
INSERT INTO tb_pekerjaan VALUES("28","Tukang Sol Sepatu");
INSERT INTO tb_pekerjaan VALUES("29","Tukang Las/Pandai Besi");
INSERT INTO tb_pekerjaan VALUES("30","Tukang Jahit");
INSERT INTO tb_pekerjaan VALUES("31","Tukang Gigi");
INSERT INTO tb_pekerjaan VALUES("32","Penata Rias");
INSERT INTO tb_pekerjaan VALUES("33","Penata Busana");
INSERT INTO tb_pekerjaan VALUES("34","Penata Rambut");
INSERT INTO tb_pekerjaan VALUES("35","Mekanik");
INSERT INTO tb_pekerjaan VALUES("36","Seniman");
INSERT INTO tb_pekerjaan VALUES("37","Tabib");
INSERT INTO tb_pekerjaan VALUES("38","Paraji");
INSERT INTO tb_pekerjaan VALUES("39","Perancang Busana");
INSERT INTO tb_pekerjaan VALUES("40","Penterjemah");
INSERT INTO tb_pekerjaan VALUES("41","Imam Masjid");
INSERT INTO tb_pekerjaan VALUES("42","Pendeta");
INSERT INTO tb_pekerjaan VALUES("43","Pastor");
INSERT INTO tb_pekerjaan VALUES("44","Wartawan");
INSERT INTO tb_pekerjaan VALUES("45","Ustadz/Mubaligh");
INSERT INTO tb_pekerjaan VALUES("46","Juru Masak");
INSERT INTO tb_pekerjaan VALUES("47","Promotor Acara");
INSERT INTO tb_pekerjaan VALUES("48","Anggota DPR-RI");
INSERT INTO tb_pekerjaan VALUES("49","Anggota DPD");
INSERT INTO tb_pekerjaan VALUES("50","Anggota BPK");
INSERT INTO tb_pekerjaan VALUES("51","Presiden");
INSERT INTO tb_pekerjaan VALUES("52","Wakil Presiden");
INSERT INTO tb_pekerjaan VALUES("53","Anggota Mahkamah Konstitusi");
INSERT INTO tb_pekerjaan VALUES("54","Anggota Kabinet Kementrian");
INSERT INTO tb_pekerjaan VALUES("55","Duta Besar");
INSERT INTO tb_pekerjaan VALUES("56","Gubernur");
INSERT INTO tb_pekerjaan VALUES("57","Wakil Gubernur");
INSERT INTO tb_pekerjaan VALUES("58","Bupati");
INSERT INTO tb_pekerjaan VALUES("59","Wakil Bupati");
INSERT INTO tb_pekerjaan VALUES("60","Walikota");
INSERT INTO tb_pekerjaan VALUES("61","Wakil Walikota");
INSERT INTO tb_pekerjaan VALUES("62","Anggota DPRP Prov");
INSERT INTO tb_pekerjaan VALUES("63","Anggota DPRP Kab/Kota");
INSERT INTO tb_pekerjaan VALUES("64","Dosen");
INSERT INTO tb_pekerjaan VALUES("65","Guru");
INSERT INTO tb_pekerjaan VALUES("66","Pilot");
INSERT INTO tb_pekerjaan VALUES("67","Pengacara");
INSERT INTO tb_pekerjaan VALUES("68","Notaris");
INSERT INTO tb_pekerjaan VALUES("69","Arsitek");
INSERT INTO tb_pekerjaan VALUES("70","Akuntan");
INSERT INTO tb_pekerjaan VALUES("71","Konsultan");
INSERT INTO tb_pekerjaan VALUES("72","Dokter");
INSERT INTO tb_pekerjaan VALUES("73","Bidan");
INSERT INTO tb_pekerjaan VALUES("74","Perawat");
INSERT INTO tb_pekerjaan VALUES("75","Apoteker");
INSERT INTO tb_pekerjaan VALUES("76","Psikiater/Psikolog");
INSERT INTO tb_pekerjaan VALUES("77","Penyiar Televisi");
INSERT INTO tb_pekerjaan VALUES("78","Penyiar Radio");
INSERT INTO tb_pekerjaan VALUES("79","Pelaut");
INSERT INTO tb_pekerjaan VALUES("80","Peneliti");
INSERT INTO tb_pekerjaan VALUES("81","Sopir");
INSERT INTO tb_pekerjaan VALUES("82","Pialang");
INSERT INTO tb_pekerjaan VALUES("83","Paranormal");
INSERT INTO tb_pekerjaan VALUES("84","Pedagang");
INSERT INTO tb_pekerjaan VALUES("85","Perangkat Desa");
INSERT INTO tb_pekerjaan VALUES("86","Kepala Desa");
INSERT INTO tb_pekerjaan VALUES("87","Biarawati");
INSERT INTO tb_pekerjaan VALUES("88","Wiraswasta");



DROP TABLE tb_pend_masuk;

CREATE TABLE `tb_pend_masuk` (
  `no_surat_masuk` varchar(30) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `nama_kk` varchar(25) NOT NULL,
  `alamat_sebelum` varchar(15) NOT NULL,
  `rt_sebelum` int(2) NOT NULL,
  `rw_sebelum` int(2) NOT NULL,
  `kec_sebelum` varchar(15) NOT NULL,
  `kab_sebelum` varchar(15) NOT NULL,
  `prov_sebelum` varchar(15) NOT NULL,
  `alasan` varchar(2) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `klsfksi_pindah` varchar(2) NOT NULL,
  `jenis_pindah` varchar(2) NOT NULL,
  `status_kk_pindah` varchar(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_surat_masuk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_pend_masuk VALUES("SKPWNI/3304/18082014/0025","3304040703054764","SARKIM","SILONGKOK KALIA","5","2","PURWANEGARA","BANJARNEGARA","JAWA TENGAH","6","1","4","4","4","1","2014-08-18");



DROP TABLE tb_pend_pindah;

CREATE TABLE `tb_pend_pindah` (
  `no_surat_pindah` varchar(20) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `nama_kk` varchar(25) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_pindah` date NOT NULL,
  `alamat_tujuan` varchar(20) NOT NULL,
  `rt_tujuan` int(2) NOT NULL,
  `rw_tujuan` int(2) NOT NULL,
  `kec_tujuan` varchar(15) NOT NULL,
  `kab_tujuan` varchar(15) NOT NULL,
  `prov_tujuan` varchar(15) NOT NULL,
  `klsfksi_pindah` varchar(2) NOT NULL,
  `jenis_pindah` varchar(2) NOT NULL,
  `status_kk_pindah` varchar(2) NOT NULL,
  `status_kk_tdkpindah` varchar(2) NOT NULL,
  `alasan` varchar(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_surat_pindah`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_pend_pindah VALUES("470/001/2014","3328021212120004","A","3","3","2014-12-15","TONJONG","2","1","TONJONG","BREBES","JAWA TENGAH","4","1","2","3","5","2014-12-12");



DROP TABLE tb_pendidikan;

CREATE TABLE `tb_pendidikan` (
  `kd_pend` int(2) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  PRIMARY KEY  (`kd_pend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_pendidikan VALUES("1","Tidak/Belum Sekolah");
INSERT INTO tb_pendidikan VALUES("2","Belum Tamat SD/Sederajat");
INSERT INTO tb_pendidikan VALUES("3","Tamat SD/Sederajat");
INSERT INTO tb_pendidikan VALUES("4","SLTP/Sederajat");
INSERT INTO tb_pendidikan VALUES("5","SLTA/Sederajat");
INSERT INTO tb_pendidikan VALUES("6","Diploma I/II");
INSERT INTO tb_pendidikan VALUES("7","Akademi/Diploma III Sarjana Muda");
INSERT INTO tb_pendidikan VALUES("8","Diploma IV/Strata I");
INSERT INTO tb_pendidikan VALUES("9","Strata II");
INSERT INTO tb_pendidikan VALUES("10","Strata III");



DROP TABLE tb_penduduk;

CREATE TABLE `tb_penduduk` (
  `no_reg_pend` varchar(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `umur` int(2) NOT NULL,
  `no_akta` varchar(20) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `no_akta_nikah` varchar(20) NOT NULL,
  `tanggal_nikah` varchar(12) NOT NULL,
  `no_akta_cerai` varchar(20) NOT NULL,
  `tanggal_cerai` varchar(12) NOT NULL,
  `status_hub` varchar(20) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `nama_ayah` varchar(30) NOT NULL,
  `nama_ibu` varchar(30) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `no_surat_kelahiran` varchar(20) NOT NULL,
  `no_surat_masuk` varchar(30) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_reg_pend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_penduduk VALUES("Reg00001","3328021005760019","M.ANSORI","Laki-laki","Brebes","1976-05-10","0","-"," Islam "," Kawin ","-","-","-","-"," Kepala Keluarga "," SLTP/Sederajat "," Wiraswasta ","SURIPNO","JARONAH","3328023101110005","-","-","1","1","2014-09-18");
INSERT INTO tb_penduduk VALUES("Reg00002","3328024608760002","FIFI ARIANTI","Perempuan","Tegal","1976-08-06","0","-"," Islam "," Kawin ","-","-","-","-"," Istri "," SLTP/Sederajat "," Mengurus Rumah Tangga ","CHAERI","WATIAH","3328023101110005","-","-","1","1","2014-09-18");
INSERT INTO tb_penduduk VALUES("Reg00003","3328024503070006","AMELIA NUR FADHILAH","Perempuan","Brebes","2007-03-05","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Belum Tamat SD/Sederajat "," Pelajar/Mahasiswa ","M.ANSORI","FIFI ARIANTI","3328023101110005","-","-","1","1","2014-09-18");
INSERT INTO tb_penduduk VALUES("Reg00004","3328023108870001","SLAMET SUMALI","Laki-laki","Tegal","1987-01-31","0","-"," Islam "," Kawin ","-","","-",""," Kepala Keluarga "," Tamat SD/Sederajat "," Wiraswasta ","JAMIN","JUMIRAH","3328022704140001","-","-","1","2","2014-07-04");
INSERT INTO tb_penduduk VALUES("Reg00005","3328025601860010","ROHANI","Laki-laki","Tegal","1986-01-16","0","-"," Islam "," Kawin ","-","","-",""," Istri "," Tamat SD/Sederajat "," Mengurus Rumah Tangga ","SARIB","ARIYAH","3328022704140001","-","-","1","1","2014-07-04");
INSERT INTO tb_penduduk VALUES("Reg00006","3320820712750004","AHMAD FRIZKI RIVAI","Laki-laki","Tegal","1975-12-07","0","-"," Islam "," Kawin ","-","","-",""," Kepala Keluarga "," Diploma IV/Strata I "," Peternak ","TJASRO SM","ZUHAROH","3328020206140002","-","-","2","1","2014-06-02");
INSERT INTO tb_penduduk VALUES("Reg00007","3328024907880003","LIDIANA","Laki-laki","Tegal","1988-07-09","0","-"," Islam "," Kawin ","-","","-",""," Istri "," SLTA/Sederajat "," Mengurus Rumah Tangga ","ROFI\'I","DURIPAH","3328020206140002","-","-","2","1","2014-07-09");
INSERT INTO tb_penduduk VALUES("Reg00008","3328026001130002","CATHLEYA SEKAR AYU LARASATI","Perempuan","Tegal","2013-01-10","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Tidak/Belum Sekolah "," Belum/Tidak Bekerja ","AHMAD FRIZKI RIVAI","LIDIANA","3328020206140002","-","-","2","1","2014-06-02");
INSERT INTO tb_penduduk VALUES("Reg00009","3328021910880008","MUKHAMAD YUNUS","Laki-laki","Tegal","1988-10-19","0","-"," Islam "," Kawin ","-","-","-","-"," Kepala Keluarga "," SLTA/Sederajat "," Wiraswasta ","KALYUB","RONAH","3328021909140013","-","-","2","1","2014-10-09");
INSERT INTO tb_penduduk VALUES("Reg00010","3328024502920003","QORINAZMI","Perempuan","Tegal","1992-02-05","0","-"," Islam "," Kawin ","-","-","-","-"," Istri "," SLTA/Sederajat "," Mengurus Rumah Tangga ","ABDURAHMAN","KODARIYAH","3328021909140013","-","-","2","1","2014-10-09");
INSERT INTO tb_penduduk VALUES("Reg00011","3328022210130002","MUHAMMAD YUQO AYUBI","Laki-laki","Tegal","2013-08-22","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Tidak/Belum Sekolah "," Belum/Tidak Bekerja ","MUKHAMAD YUNUS","QORINAZMI","3328021909140013","-","-","2","1","2014-10-09");
INSERT INTO tb_penduduk VALUES("Reg00012","-","MUZAYIN","Laki-laki","Tegal","1964-08-12","0","-"," Islam "," Kawin ","437/16/XI/1995","01-11-1995","-","-"," Kepala Keluarga "," Tamat SD/Sederajat "," Sopir ","AKTIF","MAFRUHAH","-","-","-","3","1","2014-01-06");
INSERT INTO tb_penduduk VALUES("Reg00013","-","NURNA RUKINI","Perempuan","Magelang","1973-07-18","0","-"," Islam "," Kawin ","437/16/XI/1995","01-11-1995","-","-"," Istri "," SLTP/Sederajat "," Mengurus Rumah Tangga ","MBUH","SURANI","-","-","-","3","1","2014-01-06");
INSERT INTO tb_penduduk VALUES("Reg00014","-","FADHLIYAH NURZA","Perempuan","Magelang","1996-08-19","0","4260/1996"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTP/Sederajat "," Pelajar/Mahasiswa ","MUZAYIN","NURNA RUKINI","-","-","-","3","1","2014-01-06");
INSERT INTO tb_penduduk VALUES("Reg00015","-","FAUZIATUNNISA NURZA","Perempuan","Magelang","1998-03-19","0","3727/TP/2007"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTP/Sederajat "," Pelajar/Mahasiswa ","MUZAYIN","NURNA RUKINI","-","-","-","3","1","2014-01-06");
INSERT INTO tb_penduduk VALUES("Reg00016","-","NAZIHA NABIL NURZA","Perempuan","Magelang","2007-01-19","0","10355/TP/2007"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Belum Tamat SD/Sederajat "," Pelajar/Mahasiswa ","MUZAYIN","NURNA RUKINI","-","-","-","3","1","2014-01-06");
INSERT INTO tb_penduduk VALUES("Reg00017","-","SUKAMTO","Laki-laki","Brebes","1975-08-14","0","-"," Islam "," Kawin ","132/06/VI/1994","06-06-1994","-","-"," Kepala Keluarga "," Tamat SD/Sederajat "," Buruh Harian Lepas ","KAPUT SUTIKNO","SEKHA","-","-","-","5","3","2014-01-08");
INSERT INTO tb_penduduk VALUES("Reg00018","-","TOBIAH","Perempuan","Tegal","1975-03-12","0","-"," Islam "," Kawin ","132/06/VI/1994","06-06-1994","-","-"," Istri "," Tamat SD/Sederajat "," Mengurus Rumah Tangga ","DAHLAN","DEMAH","-","-","-","5","3","2014-01-08");
INSERT INTO tb_penduduk VALUES("Reg00019","-","WIDIASTUTI","Perempuan","Tegal","1996-04-20","0","997/TPJB/2002"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTP/Sederajat "," Pelajar/Mahasiswa ","SUKAMTO","TOBIAH","-","-","-","5","3","2014-01-08");
INSERT INTO tb_penduduk VALUES("Reg00020","3328020201650001","ABDILLAH","Laki-laki","Tegal","1965-01-02","0","-","Islam","Kawin","-","-","-","-","Kepala Keluarga","SLTA/Sederajat","Wiraswasta","H.JAMIL","DUHONAH","3328022703140004","-","-","6","1","2014-03-03");
INSERT INTO tb_penduduk VALUES("Reg00021","3328026312720001","KHOYIROH","Perempuan","Tegal","1972-12-23","0","-"," Islam "," Kawin ","-","-","-","-"," Istri "," Tamat SD/Sederajat "," Mengurus Rumah Tangga ","SUKRAD","SODAH","3328022703140004","-","-","6","1","2014-03-03");
INSERT INTO tb_penduduk VALUES("Reg00022","3328020212920007","MUHAMMAD FAHMI ABDULLOH","Laki-laki","Tegal","1991-12-02","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTA/Sederajat "," Pelajar/Mahasiswa ","ABDILLAH","KHOYIROH","3328022703140004","-","-","6","1","2014-03-03");
INSERT INTO tb_penduduk VALUES("Reg00023","3328024709940011","FIFIT ROTILIHYA","Perempuan","Tegal","1994-09-07","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTA/Sederajat "," Pelajar/Mahasiswa ","ABDILLAH","KHOYIROH","3328022703140004","-","-","6","1","2014-03-03");
INSERT INTO tb_penduduk VALUES("Reg00024","3328026812960001","RO\'FA TUNNAIHI","Perempuan","Tegal","1996-12-28","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," SLTP/Sederajat "," Pelajar/Mahasiswa ","ABDILLAH","KHOYIROH","3328022703140004","-","-","6","1","2014-03-03");
INSERT INTO tb_penduduk VALUES("Reg00025","3328025402990004","FINA SILIYYA","Perempuan","Tegal","1999-02-14","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Tamat SD/Sederajat "," Pelajar/Mahasiswa ","ABDILLAH","KHOYIROH","3328022703140004","-","-","6","1","2014-03-03");
INSERT INTO tb_penduduk VALUES("Reg00026","3328021202020004","A.SIFAU NAJAH","Laki-laki","Tegal","2002-02-12","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Tamat SD/Sederajat "," Pelajar/Mahasiswa ","ABDILLAH","KHOYIROH","3328022703140004","-","-","6","1","2014-03-03");
INSERT INTO tb_penduduk VALUES("Reg00027","3328025202040003","BUNGA BANATI","Perempuan","Tegal","2004-02-12","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Belum Tamat SD/Sederajat "," Pelajar/Mahasiswa ","ABDILLAH","KHOYIROH","3328022703140004","-","-","6","1","2014-03-03");
INSERT INTO tb_penduduk VALUES("Reg00028","","ANIP","Perempuan","Banjarnegara","1985-12-15","0","-"," Islam "," Kawin ","780/36/XII/2006","19-12-2006","-","-"," Anak "," SLTP/Sederajat "," Mengurus Rumah Tangga ","SARTONO","RUSMIATI","","-","SKPWNI/3304/18082014/0025","1","4","2014-08-18");
INSERT INTO tb_penduduk VALUES("Reg00029","","AFRILIANI","Perempuan","Banjarnegara","2008-04-20","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Cucu "," Belum Tamat SD/Sederajat "," Pelajar/Mahasiswa ","KHUSNUL","ANIP","","-","SKPWNI/3304/18082014/0025","1","4","2014-08-18");
INSERT INTO tb_penduduk VALUES("Reg00030","3328020909830002","MUHAMMAD LUBSI","Laki-laki","Tegal","1983-09-09","0","-"," Islam "," Kawin ","-","-","-","-"," Kepala Keluarga "," Diploma IV/Strata I "," Wiraswasta ","M.ROJIDIN","TOIPAH","3328021809130018","-","-","6","1","2014-01-09");
INSERT INTO tb_penduduk VALUES("Reg00031","3328027007840005","SUSIAWATI","Perempuan","Surabaya","1984-07-30","0","-"," Islam "," Kawin ","-","-","-","-"," Istri "," SLTA/Sederajat "," Guru ","SUDARMAN","SURASMI ASMAIYAH","3328021809130018","-","-","6","1","2014-01-09");
INSERT INTO tb_penduduk VALUES("Reg00032","3328025611090004","KHAFDANA ITSNAN FI AHLINA","Perempuan","Tegal","2009-11-16","0","-"," Islam "," Belum Kawin ","-","-","-","-"," Anak "," Tidak/Belum Sekolah "," Belum/Tidak Bekerja ","MUHAMMAD LUBSI","SUSIAWATI","3328021809130018","-","-","6","1","2014-01-09");
INSERT INTO tb_penduduk VALUES("Reg00033","3328020708140002","MASKAN DIYAUL MISKI","Laki-laki","Tegal","2014-08-07","0","-","Islam","Belum Kawin","-","-","-","-","Anak","Tidak/Belum Sekolah","Belum/Tidak Bekerja","MUHAMMAD LUBSI","SUSIAWATI","3328021809130018","474.1/001/2014","-","6","1","2014-09-03");
INSERT INTO tb_penduduk VALUES("Reg00034","3328020708140001","SAYYIDAH LUTFANIL AULADA","Perempuan","Tegal","2014-08-07","0","-","Islam","Belum Kawin","-","-","-","-","Anak","Tidak/Belum Sekolah","Belum/Tidak Bekerja","MUHAMMAD LUBSI","SUSIAWATI","3328021809130018","474.1/002/2014","-","6","1","2014-09-03");



DROP TABLE tb_rt;

CREATE TABLE `tb_rt` (
  `no` int(2) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `nama_rt` varchar(15) NOT NULL,
  `no_rw` int(2) NOT NULL,
  PRIMARY KEY  (`no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_rt VALUES("1","1","KAIDI","1");
INSERT INTO tb_rt VALUES("2","2","TOPAN","1");
INSERT INTO tb_rt VALUES("3","3","RATNO","1");
INSERT INTO tb_rt VALUES("4","4","TAJRI","1");
INSERT INTO tb_rt VALUES("5","5","DARMO","1");
INSERT INTO tb_rt VALUES("6","6","JAWAWI","1");
INSERT INTO tb_rt VALUES("7","1","TORPUL","2");
INSERT INTO tb_rt VALUES("8","2","NASRO","2");
INSERT INTO tb_rt VALUES("9","3","SUGENG","2");
INSERT INTO tb_rt VALUES("10","4","SAMSUDIN","2");
INSERT INTO tb_rt VALUES("11","5","ROBI","2");
INSERT INTO tb_rt VALUES("12","6","WASAD","2");
INSERT INTO tb_rt VALUES("13","1","ROPI\'I","3");
INSERT INTO tb_rt VALUES("14","2","SAEFULLOH","3");
INSERT INTO tb_rt VALUES("15","3","SAKLAN","3");
INSERT INTO tb_rt VALUES("16","4","SOPANUDIN","3");
INSERT INTO tb_rt VALUES("17","5","JUBEDI","3");
INSERT INTO tb_rt VALUES("18","1","JAHIDI","4");
INSERT INTO tb_rt VALUES("19","2","SAEPUDINI","4");
INSERT INTO tb_rt VALUES("20","3","KARIRI","4");
INSERT INTO tb_rt VALUES("21","4","WASRIP","4");
INSERT INTO tb_rt VALUES("22","5","KHARIS","4");
INSERT INTO tb_rt VALUES("23","6","JAHID","4");
INSERT INTO tb_rt VALUES("24","7","DAKRI","4");
INSERT INTO tb_rt VALUES("25","8","RINTO","4");
INSERT INTO tb_rt VALUES("26","9","WALIYO","4");
INSERT INTO tb_rt VALUES("27","10","MUSLIM","4");



DROP TABLE tb_rw;

CREATE TABLE `tb_rw` (
  `no_rw` int(2) NOT NULL,
  `nama_rw` varchar(15) NOT NULL,
  PRIMARY KEY  (`no_rw`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_rw VALUES("1","DIAS");
INSERT INTO tb_rw VALUES("2","SUPARJO");
INSERT INTO tb_rw VALUES("3","WASTO");
INSERT INTO tb_rw VALUES("4","TARIP");



DROP TABLE tb_sementarakk;

CREATE TABLE `tb_sementarakk` (
  `no_reg_pend` varchar(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `no_akta` varchar(20) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `no_akta_nikah` varchar(20) NOT NULL,
  `tanggal_nikah` varchar(12) NOT NULL,
  `no_akta_cerai` varchar(20) NOT NULL,
  `tanggal_cerai` varchar(12) NOT NULL,
  `status_hub` varchar(20) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `nama_ayah` varchar(30) NOT NULL,
  `nama_ibu` varchar(30) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE tb_sementaramasuk;

CREATE TABLE `tb_sementaramasuk` (
  `no_surat_masuk` varchar(30) NOT NULL,
  `no_reg_pend` varchar(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `umur` int(2) NOT NULL,
  `no_akta` varchar(20) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `no_akta_nikah` varchar(20) NOT NULL,
  `tanggal_nikah` varchar(12) NOT NULL,
  `no_akta_cerai` varchar(20) NOT NULL,
  `tanggal_cerai` varchar(12) NOT NULL,
  `status_hub` varchar(20) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `nama_ayah` varchar(30) NOT NULL,
  `nama_ibu` varchar(30) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `no_surat_kelahiran` varchar(20) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_reg_pend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE tb_sementarapindah;

CREATE TABLE `tb_sementarapindah` (
  `no_reg_pend` varchar(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `status_hub` varchar(20) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `no_kk` varchar(16) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE tb_sktm;

CREATE TABLE `tb_sktm` (
  `no_surat` varchar(20) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  `oleh` varchar(25) NOT NULL,
  PRIMARY KEY  (`no_surat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_sktm VALUES("422.5/001/XII/2014","3328021202020004","A.SIFAU NAJAH","Laki-laki","Tegal","2002-02-12"," Islam "," Pelajar/Mahasiswa ","6","1","2014-12-10","ABDUL KHAYYI");



DROP TABLE tb_status_hub;

CREATE TABLE `tb_status_hub` (
  `id` int(2) NOT NULL,
  `status_hub` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_status_hub VALUES("1","Kepala Keluarga");
INSERT INTO tb_status_hub VALUES("2","Suami");
INSERT INTO tb_status_hub VALUES("3","Istri");
INSERT INTO tb_status_hub VALUES("4","Anak");
INSERT INTO tb_status_hub VALUES("5","Menantu");
INSERT INTO tb_status_hub VALUES("6","Cucu");
INSERT INTO tb_status_hub VALUES("7","Orangtua");
INSERT INTO tb_status_hub VALUES("8","Mertua");
INSERT INTO tb_status_hub VALUES("9","Famili Lain");
INSERT INTO tb_status_hub VALUES("10","Pembantu");
INSERT INTO tb_status_hub VALUES("11","Lainnya");



DROP TABLE tb_status_nikah;

CREATE TABLE `tb_status_nikah` (
  `id` int(2) NOT NULL,
  `status_nikah` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_status_nikah VALUES("2","Kawin");
INSERT INTO tb_status_nikah VALUES("1","Belum Kawin");
INSERT INTO tb_status_nikah VALUES("3","Cerai Hidup");
INSERT INTO tb_status_nikah VALUES("4","Cerai Mati");



DROP TABLE tb_surat;

CREATE TABLE `tb_surat` (
  `no_surat` varchar(20) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `ket` varchar(20) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY  (`no_surat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE tb_surat_domisili;

CREATE TABLE `tb_surat_domisili` (
  `no_surat` varchar(20) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `status_nikah` varchar(15) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  `oleh` varchar(25) NOT NULL,
  PRIMARY KEY  (`no_surat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_surat_domisili VALUES("474.4/001/XII/2014","","ANIP","Perempuan","Banjarnegara","1985-12-15"," Kawin "," Mengurus Rumah Tangga ","1","4","2014-12-10","ABDUL KHAYYI");



DROP TABLE tb_surat_skck;

CREATE TABLE `tb_surat_skck` (
  `no_surat` varchar(20) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  `tanggal_akhir` date NOT NULL,
  `oleh` varchar(25) NOT NULL,
  PRIMARY KEY  (`no_surat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_surat_skck VALUES("331/001/2014","3328020909830002","MUHAMMAD LUBSI","Laki-laki","Tegal","1983-09-09"," Islam "," Wiraswasta ","6","1","2014-12-10","2015-02-10","ABDUL KHAYYI");



DROP TABLE tb_surat_usaha;

CREATE TABLE `tb_surat_usaha` (
  `no_surat` varchar(20) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat` varchar(15) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar(10) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `no_rt` int(2) NOT NULL,
  `no_rw` int(2) NOT NULL,
  `tanggal_input` date NOT NULL,
  `usaha` varchar(50) NOT NULL,
  `oleh` varchar(25) NOT NULL,
  PRIMARY KEY  (`no_surat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO tb_surat_usaha VALUES("500/001/2014","3328020909830002","MUHAMMAD LUBSI","Laki-laki","Tegal","1983-09-09"," Islam "," Wiraswasta ","6","1","2014-12-10","Warnet dan Kursus Komputer","ABDUL KHAYYI");



