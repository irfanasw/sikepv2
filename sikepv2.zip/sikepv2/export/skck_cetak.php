<?php		
			
			require ('../inc/config.php');
			$no_surat=$_GET['no_surat'];
$qrykoreksi=mysql_query("select nik, DATE_FORMAT(tanggal_input, '%d-%m-%Y') as tanggal_input,no_surat, nama, tempat,
                                     DATE_FORMAT(tanggal_lahir, '%d-%m-%Y') as tanggal_lahir,pekerjaan, agama,
                                     DATE_FORMAT(tanggal_akhir, '%d-%m-%Y') as tanggal_akhir,
                                     no_rt, no_rw,oleh from tb_surat_skck where no_surat='$no_surat' LIMIT 1");
$dataku=mysql_fetch_object($qrykoreksi);

?>
<html>
	<head>
    <title> <?php echo $dataku->nama ?></title>
		<link href="../assets/css/bootstrap.css" rel="stylesheet">
		<style type="text/css">		body {
				padding-top: 20px;
				padding-bottom: 40px;
				font-size: 0.7em;
			}
</style>
	</head>
	<body >
		<div class='span1  offset12'>
        
			
                                    
                                    <table cellpadding="9" cellspacing="9">
                                    <tr>
                                    <td rowspan="5"><img src="../img/header_surat.png" width="540" height="50"/></td>
                                    </tr>
                                    </table>
                                    
                                    <table style="font-size: 12px;font-family: Times New Roman; margin-left: 25px;text-align: justify;"cellpadding="5" cellspacing="">
                                    <tr>
                                    <td colspan="4"><b style="font-size: 12px;">No. Kode Desa/Kelurahan : 33 28 02 2013</b></center></td>
                                    </tr>
                                    
                                    <tr>
                                    <td colspan="4"><center><b style="font-size: 14px;"><u>SURAT KETERANGAN/PENGANTAR</u></b></center></td>
                                    </tr>
                                    <tr>
                                    <td colspan="4"><center>Nomor : <?php echo $dataku->no_surat ?></td></center>
                                    </tr>
                                    
                                    <tr>
                                    <td colspan="4"><center>Yang bertanda tangan dibawah ini Kepala Desa Cempaka, menerangkan bahwa  :</center></td>
                                    </tr>
                                    
                                    <tr><td>&nbsp;</td></tr>
                                    
                                    <tr>
                                    <td>1.</td><td>Nama</td><td>:</td><td><b><?php echo $dataku->nama ?></b></td>
                                    </tr>
                                    <tr>
                                    <td>2.</td><td>Tempat dan Tanggal Lahir</td><td>:</td><td><?php echo $dataku->tempat ?>, &nbsp;<?php echo $dataku->tanggal_lahir ?></td>
                                    </tr>
                                    <tr>
                                    <td>3.</td><td>Kewarganegaraan & Agama</td><td>:</td><td>Indonesia / <?php echo $dataku->agama ?></td>
                                    </tr>
                                    <tr>
                                    <td>4.</td><td>Pekerjaan</td><td>:</td><td><?php echo $dataku->pekerjaan ?></td>
                                    </tr>
                                    
                                    <tr>
                                    <td>5.</td><td>Tempat Tinggal</td><td>:</td><td>Desa Cempaka RT&nbsp;0<?php echo $dataku->no_rt ?>&nbsp;RW&nbsp;0<?php echo $dataku->no_rw ?>&nbsp;Kecamatan Bumijawa</td>
                                    </tr>
                                    <tr>
                                    <td></td><td></td><td></td><td>Kabupaten Tegal Provinsi Jawa Tengah</td>
                                    </tr>
                                    <tr>
                                    <td>6.</td><td>Surat bukti diri</td><td>:</td><td>KTP No. &nbsp;<?php echo $dataku->nik ?></td>
                                    </tr>
                                    <tr>
                                    <td>7.</td><td>Keperluan</td><td>:</td><td>Untuk Pengajuan Pembuatan SKCK</td>
                                    </tr>
                                    <tr>
                                    <td>8.</td><td>Berlaku mulai</td><td>:</td><td><?php echo $dataku->tanggal_input ?> s/d <?php echo $dataku->tanggal_akhir ?></td>
                                    </tr>
                                    <tr>
                                    <td>9.</td><td>Keterangan lain-lain</td><td>:</td><td>Bahwa orang tersebut benar-benar warga kami dan berkelakuan  baik
                                    </td>
                                    </tr>
                                    <tr><td>&nbsp;</td></tr>
                                    <tr>
                                    <td colspan="4"><center>Demikian untuk menjadikan maklum bagi yang berkepentingan</center></td>
                                    </tr>
                                    <tr>
                                    <td colspan="4"><center>Nomor		:����������-���������</center></td>
                                    </tr>
                                    <tr>
                                    <td colspan="4"><center>Tanggal		:����������-���������</center></td>
                                    </tr>
                                    <tr><td>&nbsp;</td></tr>
                                    <tr>
                                    <td colspan="4" align="right">Cempaka, <?php echo $dataku->tanggal_input ?></td>
                                    </tr>
                                    <tr>
                                    <td>&nbsp;</td><td>Tanda Tangan Pemegang</td><td>&nbsp;</td><td align="right">Kepala Desa Cempaka</td>
                                    </tr>
                                    <tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
                                    <tr>
                                    <td>&nbsp;</td><td><b><u><?php echo $dataku->nama ?></u></b></td><td>&nbsp;</td><td align="right"><b><u><?php echo $dataku->oleh ?></u></b></td>
                                    </tr>
                                    </table>
                                    
                                    
                                    
            
			
		</div>
	</body>
</html>
