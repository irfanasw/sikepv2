<?php		
			
			require ('../inc/config.php');
			 mysql_connect("localhost","root","");
   mysql_select_db("kependudukanok");
			$no_surat=$_GET['no_surat'];
$qrykoreksi=mysql_query("select nik, DATE_FORMAT(tanggal_input, '%d-%m-%Y') as tanggal_input,no_surat, nama, jenis_kelamin, tempat,
                                     DATE_FORMAT(tanggal_lahir, '%d-%m-%Y') as tanggal_lahir,pekerjaan, usaha, agama,
                                     no_rt, no_rw,oleh from tb_surat_usaha where no_surat='$no_surat' LIMIT 1");
$dataku=mysql_fetch_object($qrykoreksi);

?>
<html>
	<head>
    <title> <?php echo $dataku->nama ?></title>
		<link href="../assets/css/bootstrap.css" rel="stylesheet">
		<style type="text/css">		body {
				padding-top: 20px;
				padding-bottom: 40px;
				font-size: 0.7em;
			}
</style>
	</head>
	<body>
		<div class='span1  offset12'>
        
			
                                    
                                    <table cellpadding="9" cellspacing="9">
                                  
                                    </table>
                                    
                                    <table style="font-size: 12px;font-family: Times New Roman; margin-left: 25px;text-align: justify;"cellpadding="5" cellspacing="">
                                    <tr>
                                    <td colspan="3"><center><b style="font-size: 14px;"><u>SURAT KETERANGAN USAHA</u></b></center></td>
                                    </tr>
                                    <tr>
                                    <td colspan="3"><center>Nomor : <?php echo $dataku->no_surat ?></td></center>
                                    </tr>
                                    <tr>
                                    <td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    Yang bertanda tangan dibawah ini Lurah Citangtu Kecamatan Kuningan Kabupaten</td>
                                    </tr>
                                    <tr>
                                    <td colspan="3">Kuningan, Menerangkan dengan sesungguhnya bahwa :</td>
                                    </tr>
                                    <tr><td>&nbsp;</td></tr>
                                    
                                    <tr>
                                    <td>Nama</td><td>:</td><td><b><?php echo $dataku->nama ?></b></td>
                                    </tr>
                                     <tr>
                                    <td>Jenis Kelamin</td><td>:</td><td><?php echo $dataku->jenis_kelamin ?></td>
                                    </tr>
                                    <tr>
                                    <td>Tempat/Tanggal Lahir</td><td>:</td><td><?php echo $dataku->tempat ?>, &nbsp;<?php echo $dataku->tanggal_lahir ?></td>
                                    </tr>
                                     <tr>
                                    <td>Kewarganegaraan</td><td>:</td><td></td>
                                    </tr>
                                    <tr>
                                    <td>Agama</td><td>:</td><td><?php echo $dataku->agama ?></td>
                                    </tr>
                                    <tr>
                                    <td>Pekerjaan</td><td>:</td><td><?php echo $dataku->pekerjaan ?></td>
                                    </tr>
                                    <tr>
                                    <td>Sektor Usaha</td><td>:</td><td><?php echo $dataku->usaha ?></td>
                                    </tr>
                                    <tr>
                                    <td>Tanda Bukti Diri</td><td>:</td><td>&nbsp;<?php echo $dataku->nik ?></td>
                                    </tr>
                                    <tr>
                                    <td>Tempat Tinggal</td><td>:</td><td>Kelurahan Citangtu RT&nbsp;0<?php echo $dataku->no_rt ?>&nbsp;RW&nbsp;0<?php echo $dataku->no_rw ?>&nbsp;Kec. Kuningan Kab. Kuningan</td>
                                    </tr>
                                    <tr>
                                    <td>Keterangan lainnya</td><td>:</td><td>Bahwa orang tersebut benar-benar warga kami dan memiliki
                                    </td>
                                    </tr>
                                    <tr>
                                    <td></td><td></td><td>usaha dalam bidang <?php echo $dataku->usaha ?>.</td>
                                    </tr>
                                    <tr><td>&nbsp;</td></tr>
                                    <tr>
                                    <td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    Demikian &nbsp;Surat &nbsp;Keterangan Usaha ini&nbsp;dibuat&nbsp;dengan&nbsp;sebenar-benarnya &nbsp;untuk&nbsp;dipergunakan</td>
                                    </tr>
                                    <tr>
                                    <td colspan="3">Seperlunya.</td>
                                    </tr>
                                    <tr><td>&nbsp;</td></tr>
                                    <tr>
                                    <td colspan="3" align="right">Citangtu, <?php echo $dataku->tanggal_input ?></td>
                                    </tr>
                                    <tr>
                                    <td>&nbsp;</td><td>&nbsp;</td><td align="right">Yang menerangkan,</td>
                                    </tr>
                                    <tr>
                                    <td>&nbsp;</td><td>&nbsp;</td><td align="right">Lurah Citangtu</td>
                                    </tr>
                                    <tr></tr><tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
                                    <tr>
                                    <td>&nbsp;</td><td>&nbsp;</td><td align="right"><b><u><?php echo $dataku->oleh ?></u></b></td>
                                    </tr>
                                    </table>
                                    
                                    
                                    
            
			
		</div>
	</body>
</html>
