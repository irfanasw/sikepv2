<?php

include "koneksi.php";
$nama=$_POST['nama']; 
$no_reg_pend=$_GET['no_reg_pend'];
$no_reg_pend=$_POST['no_reg_pend'];
$no_surat_pindah=$_POST['no_surat_pindah'];

$q1="insert into tb_sementarapindah( no_reg_pend, nama,nik, jenis_kelamin,tempat, tanggal_lahir,agama,status_nikah,status_hub,pendidikan,pekerjaan, no_kk,no_rt,no_rw) select no_reg_pend, nama,nik, jenis_kelamin,tempat, tanggal_lahir,agama, status_nikah,status_hub, pendidikan,pekerjaan,no_kk,no_rt,no_rw from tb_penduduk where nama='$nama' limit 1";
mysql_query($q1)or die(mysql_error());
$query=mysql_query("select * from tb_sementarapindah");
        while($r=mysql_fetch_row($query)){
            mysql_query("insert into tb_detail_pend_pindah(no_surat_pindah,no_reg_pend,nik,nama, jenis_kelamin,tempat, tanggal_lahir,agama,status_nikah, status_hub,pekerjaan, pendidikan,no_kk,no_rt,no_rw)
                        values('$no_surat_pindah','$r[0]','$r[1]','$r[2]','$r[3]','$r[4]','$r[5]','$r[6]','$r[7]','$r[8]','$r[9]','$r[10]','$r[11]','$r[12]','$r[13]')");
              mysql_query("delete from tb_penduduk where no_reg_pend ='$r[0]'")or die(mysql_error());
            }

 mysql_query("delete from tb_sementarapindah");
echo '<script type="text/javascript">javascript:history.back()</script>';
?>