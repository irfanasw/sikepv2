<?php

include "koneksi.php";
$no_reg_kk=$_GET['no_reg_kk'];
$no_reg_kk=$_POST['no_reg_kk'];
$nama_kk=$_POST['nama_kk'];
$no_rt=$_POST['no_rt'];
$no_rw=$_POST['no_rw'];
$tanggal_input = $_POST['tanggal_input'];

$sementara=mysql_query("select *  from tb_detail_kk where no_reg_kk='$no_reg_kk'");   
$jml_anggota = mysql_num_rows($sementara);
$q1="update  tb_kk set nama_kk='$nama_kk',no_rt='$no_rt',no_rw='$no_rw',jml_anggota='$jml_anggota' where no_reg_kk='$no_reg_kk'";
mysql_query($q1)or die(mysql_error());

echo '<script type="text/javascript">alert("Berhasil! Data telah diupdate");
location.href="kk.php";</script>';



?>