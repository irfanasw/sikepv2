<?php

include "koneksi.php";
                    
                    $no_rw=$_POST['no_rw'];
                    $nama_rw=$_POST['nama_rw'];
                    
                   if (empty($nama_rw))
                    {
                    die("Isikan Nama!");
                    }
                    
                    else
                    {
                    
                    
                    $myquery="update tb_rw set nama_rw='$nama_rw' WHERE no_rw='$no_rw' LIMIT 1";
                    mysql_query($myquery) or die(mysql_error());
                    
                    echo '<script type="text/javascript">alert("Data telah diupdate, Silahkan tunggu...");
                    location.href="rt.php";</script>';
                    }
                    
                    exit;

?>