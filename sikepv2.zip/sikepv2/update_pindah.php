<?php



include "koneksi.php";
$no_surat_pindah=$_GET['no_surat_pindah'];
$no_reg_pend=$_GET['no_reg_pend'];
$no_reg_pend=$_POST['no_reg_pend'];
$nama_kk=$_POST['nama_kk'];
$no_kkk=$_POST['no_kkk'];
$no_rt=$_POST['no_rt'];
$no_rw=$_POST['no_rw'];
$tanggal_input = $_POST['tanggal_input'];
$no_surat_pindah=$_POST['no_surat_pindah'];
$alamat_tujuan=$_POST['alamat_tujuan'];
$rt_tujuan=$_POST['rt_tujuan'];
$rw_tujuan=$_POST['rw_tujuan'];
$kec_tujuan=$_POST['kec_tujuan'];
$kab_tujuan=$_POST['kab_tujuan'];
$prov_tujuan=$_POST['prov_tujuan'];
$klsfksi_pindah=$_POST['klsfksi_pindah'];
$jenis_pindah=$_POST['jenis_pindah'];
$alasan=$_POST['alasan'];
$status_kk_pindah=$_POST['status_kk_pindah'];
$status_kk_tdkpindah=$_POST['status_kk_tdkpindah'];
$tanggal_pindah = $_POST['tanggal_pindah'];
$q1="update  tb_pend_pindah set nama_kk='$nama_kk',no_kk='$no_kkk',no_rt='$no_rt',no_rw='$no_rw',tanggal_pindah='$tanggal_pindah',alamat_tujuan='$alamat_tujuan',rt_tujuan='$rt_tujuan',rw_tujuan='$rw_tujuan', kec_tujuan='$kec_tujuan',kab_tujuan='$kab_tujuan',prov_tujuan='$prov_tujuan',klsfksi_pindah='$klsfksi_pindah',jenis_pindah='$jenis_pindah',status_kk_tdkpindah='$status_kk_tdkpindah',status_kk_pindah='$status_kk_pindah',tanggal_input='$tanggal_input',alasan='$alasan' where no_surat_pindah='$no_surat_pindah'";
mysql_query($q1)or die(mysql_error());

echo '<script type="text/javascript">alert("Berhasil! Data telah diupdate");
location.href="pend_pindah.php";</script>';

?>