<?php



                include "koneksi.php";
                $no=$_POST['no'];
                $no_rt=$_POST['no_rt'];
                $nama_rt=$_POST['nama_rt'];
                $no_rw=$_POST['no_rw'];
                $nama_rw=$_POST['nama_rw'];
                
                if (empty($no_rt))
                {
                die("Isikan RT!");
                }
                elseif(empty($nama_rt))
                {
                die("Isikan Nama!");
                }
                else
                {
                                    
                
                $myquery="update tb_rt set nama_rt='$nama_rt' WHERE no='$no' LIMIT 1";
                mysql_query($myquery) or die(mysql_error());
                
                echo '<script type="text/javascript">alert("Data telah diupdate, Silahkan tunggu...");
                location.href="rt.php";</script>';
                
                }
                exit;
                
            

?>