<?php


include "koneksi.php";
$nik = $_GET['nik'];
$myquery = "delete from tb_detail_ktp where nik ='$nik' limit 1";
$hapus = mysql_query($myquery) or die ("gagal menghapus");
$myquery1 = "delete from tb_ktp where nik ='$nik' limit 1";
$hapus = mysql_query($myquery1) or die ("gagal menghapus");
echo '<script type="text/javascript">alert("Data telah dihapus, Silahkan tunggu...");
location.href="ktp.php";</script>';

?>