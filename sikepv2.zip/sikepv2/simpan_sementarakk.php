<?php

include "koneksi.php";
$no_reg_pend=$_POST['no_reg_pend']; 
$q1="insert into tb_sementarakk( no_reg_pend, nama,nik, jenis_kelamin,tempat, tanggal_lahir,no_akta, agama,status_nikah, no_akta_nikah,tanggal_nikah,no_akta_cerai,tanggal_cerai,  status_hub, pendidikan,pekerjaan,nama_ayah,nama_ibu,no_rt,no_rw) select no_reg_pend, nama,nik, jenis_kelamin,tempat, tanggal_lahir,no_akta, agama,status_nikah, no_akta_nikah,tanggal_nikah,no_akta_cerai,tanggal_cerai, status_hub, pendidikan,pekerjaan,nama_ayah,nama_ibu,no_rt,no_rw from tb_penduduk where no_reg_pend='$no_reg_pend' limit 1";
mysql_query($q1)or die(mysql_error());
header ("location:input_kk.php");                                          

?>