<?php


include "koneksi.php";

$no_kkk=$_POST['no_kkk'];
$nama_kk=$_POST['nama_kk'];
$no_surat_masuk=$_POST['no_surat_masuk'];
$no_rt=$_POST['no_rt'];
$no_rw=$_POST['no_rw'];
$tanggal_input = $_POST['tanggal_input'];
$alamat_sebelum=$_POST['alamat_sebelum'];
$rt_sebelum=$_POST['rt_sebelum'];
$rw_sebelum=$_POST['rw_sebelum'];
$kec_sebelum=$_POST['kec_sebelum'];
$kab_sebelum=$_POST['kab_sebelum'];
$prov_sebelum=$_POST['prov_sebelum'];
$klsfksi_pindah=$_POST['klsfksi_pindah'];
$jenis_pindah=$_POST['jenis_pindah'];
$alasan=$_POST['alasan'];
$status_kk_pindah=$_POST['status_kk_pindah'];
if(empty($nama_kk))
{
die("Isikan Nama!");
}
else
{
$myquery1="update tb_pend_masuk set nama_kk='$nama_kk',no_kk='$no_kkk',no_rt='$no_rt',no_rw='$no_rw',alamat_sebelum='$alamat_sebelum',rt_sebelum='$rt_sebelum',rw_sebelum='$rw_sebelum', kec_sebelum='$kec_sebelum',kab_sebelum='$kab_sebelum',prov_sebelum='$prov_sebelum',klsfksi_pindah='$klsfksi_pindah',jenis_pindah='$jenis_pindah',status_kk_pindah='$status_kk_pindah',tanggal_input='$tanggal_input',alasan='$alasan' where no_surat_masuk='$no_surat_masuk'";

mysql_query($myquery1) or die(mysql_error());

echo '<script type="text/javascript">alert("Data telah diupdate, Silahkan tunggu...");
location.href="pend_masuk.php";</script>';
}


?>

