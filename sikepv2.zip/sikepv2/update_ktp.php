<?php

include "koneksi.php";
$no_reg_pend=$_POST['no_reg_pend'];
$nik=$_POST['nik'];
$nama=$_POST['nama'];
$tempat=$_POST['tempat'];
$tanggal_lahir = $_POST['tanggal_lahir'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$agama=$_POST['agama'];
$status_nikah=$_POST['status_nikah'];
$status_hub=$_POST['status_hub'];
$pendidikan=$_POST['pendidikan'];
$pekerjaan=$_POST['pekerjaan'];
$no_kk=$_POST['no_kk'];
$no_rt=$_POST['no_rt'];
$no_rw=$_POST['no_rw'];
$tanggal_input = $_POST['tanggal_input'];
$tanggal_berlaku = $_POST['tanggal_berlaku'];


if(empty($nama))
{
die("Isikan Nama!");
}
else
{
$myquery1="update tb_detail_ktp set nama='$nama',jenis_kelamin='$jenis_kelamin',tempat='$tempat',".
"tanggal_lahir='$tanggal_lahir',agama='$agama',status_nikah='$status_nikah',status_hub='$status_hub',pendidikan='$pendidikan',pekerjaan='$pekerjaan',no_kk='$no_kk',no_rt='$no_rt',no_rw='$no_rw' WHERE nik='$nik' LIMIT 1";
mysql_query($myquery1) or die(mysql_error());
$myquery2="update tb_ktp set tanggal_input='$tanggal_input',tanggal_berlaku='$tanggal_berlaku' WHERE nik='$nik' LIMIT 1";
mysql_query($myquery2) or die(mysql_error());
$myquery3="update tb_penduduk set nama='$nama',jenis_kelamin='$jenis_kelamin',tempat='$tempat',".
"tanggal_lahir='$tanggal_lahir',agama='$agama',status_nikah='$status_nikah',status_hub='$status_hub',pendidikan='$pendidikan',pekerjaan='$pekerjaan',no_kk='$no_kk',no_rt='$no_rt',no_rw='$no_rw' WHERE nik='$nik' LIMIT 1";
mysql_query($myquery3) or die(mysql_error());


echo '<script type="text/javascript">alert("Berhasil! Data telah diupdate");
location.href="ktp.php";</script>';
}


?>

