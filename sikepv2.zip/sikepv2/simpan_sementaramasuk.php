<?php

include "koneksi.php";
$no_reg_pend=$_POST['no_reg_pend'];
$nik=$_POST['nik'];
$nama=$_POST['nama'];
$tempat=$_POST['tempat'];
$tanggal_lahir =  $_POST['thn_lhr']."-".$_POST['bln_lhr']."-".$_POST['tgl_lhr'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$no_akta=$_POST['no_akta'];
$agama=$_POST['agama'];
$status_nikah=$_POST['status_nikah'];
$no_akta_nikah=$_POST['no_akta_nikah'];
$tanggal_nikah =  $_POST['tanggal_nikah'];
$no_akta_cerai=$_POST['no_akta_cerai'];
$tanggal_cerai =  $_POST['tanggal_cerai'];
$status_hub=$_POST['status_hub'];
$pendidikan=$_POST['pendidikan'];
$pekerjaan=$_POST['pekerjaan'];
$nama_ayah=$_POST['nama_ayah'];
$nama_ibu=$_POST['nama_ibu'];
$no_kk=$_POST['no_kk'];
$no_surat_kelahiran=$_POST['no_surat_kelahiran'];
$no_rt=$_POST['no_rt'];
$no_rw=$_POST['no_rw'];
$no_surat_masuk=$_POST['no_surat_masuk'];
$tanggal_input = $_POST['tanggal_input'];

$intro = $nama;
$nm = strtoupper($intro);
$intri = $nama_ayah;
$ayah= strtoupper($intri);
$intru = $nama_ibu;
$ibu= strtoupper($intru);

$q2="insert into tb_penduduk(no_reg_pend,nik,nama,jenis_kelamin,tempat,tanggal_lahir,umur, no_akta,agama,status_nikah,no_akta_nikah,tanggal_nikah,no_akta_cerai,tanggal_cerai,status_hub,pendidikan,pekerjaan,nama_ayah,nama_ibu, no_kk,no_surat_kelahiran,no_rt,no_rw,no_surat_masuk,tanggal_input) " .
 "values('$no_reg_pend','$nik','$nm','$jenis_kelamin','$tempat','$tanggal_lahir','$umur','$no_akta','$agama','$status_nikah','$no_akta_nikah','$tanggal_nikah','$no_akta_cerai','$tanggal_cerai','$status_hub','$pendidikan','$pekerjaan','$ayah','$ibu','$no_kk','$no_surat_kelahiran','$no_rt','$no_rw','$no_surat_masuk','$tanggal_input')";
mysql_query($q2)or die(mysql_error());
$q1="insert into tb_sementaramasuk(no_reg_pend,nik,nama,jenis_kelamin,tempat,tanggal_lahir,umur, no_akta,agama,status_nikah,no_akta_nikah,tanggal_nikah,no_akta_cerai,tanggal_cerai,status_hub,pendidikan,pekerjaan,nama_ayah,nama_ibu, no_kk,no_surat_kelahiran,no_rt,no_rw,no_surat_masuk,tanggal_input) " .
 "values('$no_reg_pend','$nik','$nm','$jenis_kelamin','$tempat','$tanggal_lahir','$umur','$no_akta','$agama','$status_nikah','$no_akta_nikah','$tanggal_nikah','$no_akta_cerai','$tanggal_cerai','$status_hub','$pendidikan','$pekerjaan','$ayah','$ibu','$no_kk','$no_surat_kelahiran','$no_rt','$no_rw','$no_surat_masuk','$tanggal_input')";
mysql_query($q1)or die(mysql_error());

echo '<script type="text/javascript">alert("Berhasil! Data baru telah ditambahkan");
location.href="input_masuk.php";</script>';
?>