<?php

include "koneksi.php";
$no_reg_pend=$_POST['no_reg_pend'];
$no_surat_kelahiran=$_POST['no_surat_kelahiran'];
$nama=$_POST['nama'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$hari=$_POST['hr']." ".$_POST['pasaran'];
$tempat=$_POST['tempat'];
$tanggal_lahir =  $_POST['thn_lhr']."-".$_POST['bln_lhr']."-".$_POST['tgl_lhr'];
$nama_ayah=$_POST['nama_ayah'];
$nama_ibu=$_POST['nama_ibu'];
$no_kk=$_POST['no_kk'];
$no_rt=$_POST['no_rt'];
$no_rw=$_POST['no_rw'];
$tanggal_input = $_POST['tanggal_input'];
$intro = $nama;
$nm = strtoupper($intro);
$intri = $nama_ayah;
$ayah= strtoupper($intri);
$intru = $nama_ibu;
$ibu= strtoupper($intru);
if (empty($nama))
{
die("Isikan Nama!");
}

else
{
$myquery1="update tb_kelahiran set nama='$nm',jenis_kelamin='$jenis_kelamin',hari='$hari', tempat='$tempat',tanggal_lahir='$tanggal_lahir',nama_ibu='$ibu',nama_ayah='$ayah',no_kk='$no_kk',no_rt='$no_rt',no_rw='$no_rw', tanggal_input='$tanggal_input' WHERE no_surat_kelahiran='$no_surat_kelahiran' LIMIT 1";

$myquery2="update tb_penduduk set nama='$nm',jenis_kelamin='$jenis_kelamin',tempat='$tempat',tanggal_lahir='$tanggal_lahir',nama_ayah='$ayah',nama_ibu='$ibu',no_kk='$no_kk',no_rt='$no_rt',no_rw='$no_rw', tanggal_input='$tanggal_input' WHERE no_surat_kelahiran='$no_surat_kelahiran' LIMIT 1";
mysql_query($myquery1) or die(mysql_error());
mysql_query($myquery2) or die(mysql_error());

echo '<script type="text/javascript">alert("Data telah diupdate, Silahkan tunggu...");
location.href="kelahiran.php";</script>';
}


?>

