<?php

include "koneksi.php";
$no_reg_pend=$_POST['no_reg_pend'];
$nik=$_POST['nik'];
$nama=$_POST['nama'];
$tempat=$_POST['tempat'];
$tanggal_lahir = $_POST['thn_lhr']."-".$_POST['bln_lhr']."-".$_POST['tgl_lhr'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$no_akta=$_POST['no_akta'];
$agama=$_POST['agama'];
$status_nikah=$_POST['status_nikah'];
$no_akta_nikah=$_POST['no_akta_nikah'];
$tanggal_nikah = $_POST['tanggal_nikah'];
$no_akta_cerai=$_POST['no_akta_cerai'];
$tanggal_cerai = $_POST['tanggal_cerai'];
$status_hub=$_POST['status_hub'];
$pendidikan=$_POST['pendidikan'];
$pekerjaan=$_POST['pekerjaan'];
$nama_ayah=$_POST['nama_ayah'];
$nama_ibu=$_POST['nama_ibu'];
$no_kk=$_POST['no_kk'];
$no_surat_kelahiran=$_POST['no_surat_kelahiran'];
$no_surat_masuk=$_POST['no_surat_masuk'];
$no_rt=$_POST['no_rt'];
$no_rw=$_POST['no_rw'];
$tanggal_input = $_POST['tanggal_input'];
$umur=$POST['umur'];

$intro = $nama;
$nm = strtoupper($intro);
$intri = $nama_ayah;
$ayah= strtoupper($intri);
$intru = $nama_ibu;
$ibu= strtoupper($intru);

if(empty($nama))
{
die("Isikan Nama!");
}
else
{
$myquery="update tb_penduduk set nik='$nik', nama='$nm',jenis_kelamin='$jenis_kelamin',tempat='$tempat',".
"tanggal_lahir='$tanggal_lahir',umur='$umur',no_akta='$no_akta',agama='$agama',status_nikah='$status_nikah',no_akta_nikah='$no_akta_nikah',tanggal_nikah='$tanggal_nikah',no_akta_cerai='$no_akta_cerai',tanggal_cerai='$tanggal_cerai',status_hub='$status_hub',pendidikan='$pendidikan',pekerjaan='$pekerjaan',nama_ayah='$ayah',nama_ibu='$ibu',no_kk='$no_kk',no_surat_kelahiran='$no_surat_kelahiran', no_surat_masuk='$no_surat_masuk',no_rt='$no_rt',no_rw='$no_rw', tanggal_input='$tanggal_input' WHERE no_reg_pend='$no_reg_pend' LIMIT 1";
mysql_query($myquery) or die(mysql_error());
$myquery1="update tb_sementaramasuk set nik='$nik', nama='$nm',jenis_kelamin='$jenis_kelamin',tempat='$tempat',".
"tanggal_lahir='$tanggal_lahir',umur='$umur',no_akta='$no_akta',agama='$agama',status_nikah='$status_nikah',no_akta_nikah='$no_akta_nikah',tanggal_nikah='$tanggal_nikah',no_akta_cerai='$no_akta_cerai',tanggal_cerai='$tanggal_cerai',status_hub='$status_hub',pendidikan='$pendidikan',pekerjaan='$pekerjaan',nama_ayah='$ayah',nama_ibu='$ibu',no_kk='$no_kk',no_surat_kelahiran='$no_surat_kelahiran', no_surat_masuk='$no_surat_masuk',no_rt='$no_rt',no_rw='$no_rw', tanggal_input='$tanggal_input' WHERE no_reg_pend='$no_reg_pend' LIMIT 1";
mysql_query($myquery1) or die(mysql_error());
echo '<script type="text/javascript">alert("Berhasil! Data telah diupdate");
location.href="input_masuk.php";</script>';
}


?>

